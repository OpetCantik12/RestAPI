<?php	
	$conn = new mysqli("localhost", "root", "", "perpustakaan");
		// cek koneksi
	if ($conn->connect_error) {
		die("koneksi gagal:" .mysqli_connect_error);
	}
   
?>
	