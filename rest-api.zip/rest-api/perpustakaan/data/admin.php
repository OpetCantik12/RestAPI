<!DOCTYPE html>
<html>
<head>
    <title>Halaman Admin</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body id="admin">
<nav class="navbar navbar-expand-lg navbar-light fixed-top bg-grey">
    <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="#admin">Admin</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="halamansearch.php">Search</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="halamanabjad.php">A-Z</a>
            </li>
        </ul>
    </div>
</nav>

<div class="container mt-5">
    <br>
    <br>
    <br>
    <h3 algin ="center">MENU ADMIN</h3>
    <br>
    <br>
    <a href="tambah.php" class="btn btn-primary mb-3">Tambah Daftar Buku</a>
    <table border="2" class="table">
        <thead>
            <tr bgcolor="#8FBC8F" align="center">
                <th>Gambar</th>
                <th>Judul</th>
                <th>Penulis</th>
                <th>Penerbit</th>
                <th>Tgl Terbit</th>
                <th>Kategori</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $url = "http://localhost/rest-api/perpustakaan/data/tampil_all.php/";
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'GET',
            ));

            $response = curl_exec($curl);
            curl_close($curl);
            $data = json_decode($response, true);

            if (!empty($data)) {
                foreach ($data as $data) {
                    echo "<tr>";
                    echo "<td><img src='../img/" . $data['gambar'] . "' alt='Gambar' width='80'></td>";
                    echo "<td>" . $data['judul'] . "</td>";
                    echo "<td>" . $data['penulis'] . "</td>";
                    echo "<td>" . $data['penerbit'] . "</td>";
                    echo "<td>" . $data['tgl_terbit'] . "</td>";
                    echo "<td>" . $data['kategori'] . "</td>";
                    echo "<td>
                            <a href='api_update.php?updateid=" . $data['id'] . "' class='btn btn-primary btn-sm'>Edit</a>
                            <a href='javascript:void(0);' class='btn btn-danger btn-sm delete-btn' data-id='" . $data['id'] . "'>Hapus</a>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7'>Tidak ada film Drakor ;(.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<script>
$(document).ready(function() {
    $('.delete-btn').click(function() {
        var id = $(this).data('id');
        var confirmDelete = confirm("Apakah Anda yakin ingin menghapus buku ini?");
        if (confirmDelete) {
            $.ajax({
                url: "api_hapus.php?id=" + id,
                type: "DELETE",
                success: function(response) {
                    var result = JSON.parse(response);
                    if (result.RESPONSE === "SUCCESS") {
                        alert("Buku berhasil dihapus");
                        location.reload();
                    } else {
                        alert("Gagal menghapus buku");
                    }
                },
                error: function() {
                    alert("Terjadi kesalahan saat menghapus buku");
                }
            });
        }
    });
});
</script>
</body>
</html>