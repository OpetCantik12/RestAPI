<?php
require_once('../config/koneksi_db.php');
header("Content-Type: application/json");
$json = file_get_contents("php://input");
$data = json_decode($json, true);

        $judul    = "";
        $penulis = "";
        $penerbit    = "";
        $tgl_terbit    = "";
        $kategori  = "";
        $gambar   = "";

        if (isset($data['judul'])) {
            $judul = $data['judul'];
        }
        if (isset($data['penulis'])) {
            $penulis = $data['penulis'];
        }
        if (isset($data['penerbit'])) {
            $penerbit = $data['penerbit'];
        }
        if (isset($data['tgl_terbit'])) {
            $tgl_terbit = $data['tgl_terbit'];
        }
        if (isset($data['kategori'])) {
            $kategori = $data['kategori'];
        }
        if (isset($data['gambar'])) {
            $gambar = $data['gambar'];
        }

        if ($judul != "") {
            $sql = $conn->prepare("INSERT INTO buku (judul, penulis, penerbit, tgl_terbit, kategori, gambar) VALUES (?, ?, ?, ?, ?, ?)");
            $sql->bind_param('ssssss', $judul, $penulis, $penerbit, $tgl_terbit, $kategori, $gambar);
            $result = $sql->execute();

            if ($result) {
                echo json_encode(array('RESPONSE' => 'SUCCESS'));
            } else {
                echo json_encode(array('RESPONSE' => 'FAILED'));
            }
        } else {
            echo json_encode(array('RESPONSE' => 'FAILED'));
        }
        ?>