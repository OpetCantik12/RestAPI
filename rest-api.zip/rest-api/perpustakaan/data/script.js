function Semuabuku(){
    $.getJSON('http://localhost/rest-api/perpustakaan/data/tampil_all.php/', function (perpustakaan){

    $.each(perpustakaan, function (i, data) {
        $('#daftar-perpustakaan').append('<div class="col-md-4"><div class="card mb-3"><img src="../img/'+  data.gambar+'"class="card-img-top"><div class="card-body"><h5 class="card-title">'+ data.judul +'</h5><p class="card-text">'+ data.penulis +'</p><p class="card-text">'+ data.penerbit + '</h6><p class="card-text">'+ data.tgl_terbit + '</h6><p class="card-text">'+ data.kategori +'</p><a href="#" class="btn btn-primary">Cek lebih detail</a></div></div></div>');

    });
});
}
Semuabuku();