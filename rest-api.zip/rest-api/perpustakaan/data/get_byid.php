<?php
 require_once('../config/koneksi_db.php');

 $myarray = array();
 if (isset($_GET['id'])){
    $id=$_GET['id'];

    if($result = mysqli_query($conn, "SELECT * FROM buku WHERE id=$id")){
        while ($row = $result->fetch_array(MYSQLI_ASSOC)){
            $myarray[] = $row;
        }
        mysqli_close($conn);
        echo json_encode($myarray);
    }
 }
?>