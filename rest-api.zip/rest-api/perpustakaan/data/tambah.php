<!DOCTYPE html>
<html>
<head>
    <title>Restful API</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
</head>
<body>
<div class="container">
    <br>
    <h1>Tambah Daftar Buku</h1>
    <br>
    <br>
    <form id="tambahForm" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="judul">Judul :</label>
            <input type="text" class="form-control" id="judul" name="judul" required>
        </div>
        <div class="form-group">
            <label for="penulis">Penulis :</label>
            <input type="text" class="form-control" id="penulis" name="penulis" required>
        </div>
        <div class="form-group">
            <label for="penerbit">Penerbit :</label>
            <input type="text" class="form-control" id="penerbit" name="penerbit" required>
        </div>
        <div class="form-group">
            <label for="tgl_terbit">Tgl Terbit :</label>
            <input type="text" class="form-control" id="tgl_terbit" name="tgl_terbit" required>
        </div>
        <div class="form-group">
            <label for="kategori">Kategori :</label>
            <input type="text" class="form-control" id="kategori" name="kategori" required>
        </div>
        <div class="form-group">
            <label for="gambar">Gambar :</label>
            <input type="text" class="form-control" id="gambar" name="gambar" required>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="admin.php" class="btn btn-primary">Back</a>
    </form>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<script>
document.getElementById("tambahForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Mencegah form submit secara default

    // Menggunakan Fetch API untuk mengirim data ke API
    fetch("api_tambah.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            judul: document.getElementById("judul").value,
            penulis: document.getElementById("penulis").value,
            penerbit: document.getElementById("penerbit").value,
            tgl_terbit: document.getElementById("tgl_terbit").value,
            kategori: document.getElementById("kategori").value,
            gambar: document.getElementById("gambar").value
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.RESPONSE === "SUCCESS") {
            alert("Data telah tersimpan!"); // Tampilkan popup sukses
            // Reset form
            document.getElementById("tambahForm").reset();
            // Arahkan ke halaman admin.php
            window.location.href = "admin.php";
        } else {
            alert("Data gagal tersimpan!"); // Tampilkan popup gagal
        }
    })
    .catch(error => {
        alert("Terjadi kesalahan dalam menyimpan data!");
        console.error(error);
    });
});
</script>
</body>
</html>