
<?php

require_once('../config/koneksi_db.php');


$json = file_get_contents("php://input");
$data = json_decode($json, true);


$id = "";
$judul = "";
$penulis = "";
$penerbit = "";
$tgl_terbit = "";
$kategori = "";

if (isset($data['id'])) {
    $id = $data['id'];
}
if (isset($data['judul'])) {
    $judul = $data['judul'];
}
if (isset($data['penulis'])) {
    $penulis = $data['penulis'];
}
if (isset($data['penerbit'])) {
    $penerbit = $data['penerbit'];
}
if (isset($data['tgl_terbit'])) {
    $tgl_terbit = $data['tgl_terbit'];
}
if (isset($data['kategori'])) {
    $kategori = $data['kategori'];
}


$response  = [];
$response['success'] = false;
$response['message'] = "data gak masuk!";
$response['data'] = [];

if ($id != "") {
    $sql = "INSERT INTO buku(id,judul,penulis,penerbit,tgl_terbit,kategori)
				VALUES('$id','$judul','$penulis','$penerbit','$tgl_terbit','$kategori')";


    $result = $conn->query($sql);
    if ($result) {

        $last_id = $conn->insert_id;
        $sql_get = "SELECT * FROM buku where id = '$last_id'";
        $result_get = $conn->query($sql_get);

        $data_get = [];
        while ($row = $result_get->fetch_assoc()) {
            $temp = $row;
            $temp['id'] = (int)$row['id'];
            array_push($data_get, $temp);
        }

        $data_get = $data_get[0];

        $response['success'] = true;
        $response['message'] = "sip data udah masuk!";
        $response['data'] = $data_get;
    } else {
        $response['success'] = false;
        $response['message'] = "error broh!";
        $response['data'] = [];
    }
}

$conn->close();


if ($response['success']) {
    header("HTTP/1.1 200");
} else {
    header("HTTP/1.1 500");
}

header('Content-Type: application/json');
echo json_encode($response);

?>