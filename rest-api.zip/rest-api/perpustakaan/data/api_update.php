<?php
include '../config/koneksi_db.php';
$id=$_GET['updateid'];
if(isset($_POST['submit'])){
    $judul=$_POST['judul'];
    $penulis=$_POST['penulis'];
    $penerbit=$_POST['penerbit'];
    $tgl_terbit=$_POST['tgl_terbit'];
    $kategori=$_POST['kategori'];
    $gambar=$_POST['gambar'];

    $sql="update 'crud' set id=$id, judul='$judul', penulis='$penulis', penerbit='$penerbit', tgl_terbit='$tgl_terbit', kategori='$kategori', gambar='$gambar' where id=$id";
    $result=mysqli_query($con, $sql);
    if ($result) {
        echo json_encode(array('RESPONSE' => 'SUCCESS'));
    } else {
        echo json_encode(array('RESPONSE' => 'FAILED'));
    }
} else {
    echo "GAGAL";
}

?>

<?php
?>
<!DOCTYPE html>
<html>
<head>
    <title>Restful API</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
</head>
<body>
<div class="container">
    <br>
    <h1>Tambah Daftar Buku</h1>
    <br>
    <br>
    <form id="tambahForm" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="judul">Judul :</label>
            <input type="text" class="form-control" id="judul" name="judul" required>
        </div>
        <div class="form-group">
            <label for="penulis">Penulis :</label>
            <input type="text" class="form-control" id="penulis" name="penulis" required>
        </div>
        <div class="form-group">
            <label for="penerbit">Penerbit :</label>
            <input type="text" class="form-control" id="penerbit" name="penerbit" required>
        </div>
        <div class="form-group">
            <label for="tgl_terbit">Tgl Terbit :</label>
            <input type="text" class="form-control" id="tgl_terbit" name="tgl_terbit" required>
        </div>
        <div class="form-group">
            <label for="kategori">Kategori :</label>
            <input type="text" class="form-control" id="kategori" name="kategori" required>
        </div>
        <div class="form-group">
            <label for="gambar">Gambar :</label>
            <input type="text" class="form-control" id="gambar" name="gambar" required>
        </div>
        <button type="submit" class="btn btn-primary">Ubah</button>
        <a href="admin.php" class="btn btn-primary">Back</a>
    </form>
</div>
</div>

