<?php
    require_once('../config/koneksi_db.php');
    $data = json_decode(file_get_contents("php://input"));

    if($data->id!=null){
        $id                 = $data->id;
        $judul              = $data->judul;
        $penulis            = $data->penulis;
        $penerbit           = $data->penerbit;
        $tgl_terbit         = $data->tgl_terbit;
        $kategori           = $data->kategori;

        $sql = $conn->prepare("UPDATE buku SET judul=?, penulis=?, penerbit=?, tgl_terbit=?, kategori=? WHERE id=?");
        $sql->bind_param('sssssd', $judul, $penulis, $penerbit, $tgl_terbit, $kategori, $id);
        $sql->execute();
        if($sql){
            echo json_encode(array('RESPONSE' => 'SUCCESS'));
        }else{
            echo json_encode(array('RESPONSE' => 'FAILED!'));
        }
    }else{
        echo "GAGAL!"; 
    }
?>